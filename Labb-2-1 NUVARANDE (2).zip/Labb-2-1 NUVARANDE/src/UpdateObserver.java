import java.awt.*;
import java.util.ArrayList;

/**
 * Created by brandts on 2018-02-26.
 */
public interface UpdateObserver {
	void actOnUpdate(ArrayList<String> vehicleNames, ArrayList<Point> carPoints, ArrayList<Double> speeds);
}
