/**
 * Created by brandts on 2018-02-26.
 */
public class CarApplication {
	protected CarModel carModel;
	protected CarController carController;
	protected CarView carView;

	public CarApplication() {
		this.carModel = new CarModel();
		carModel.cars = VehicleFactory.standardVehicles();
		this.carView = new CarView(800, 800 - 240);
		this.carController = new CarController("Car Sim 2.0",carModel, carView);
		carModel.updateObserver = carView;

	}

	public static void main(String[] args) {
		CarApplication carApplication = new CarApplication();
		carApplication.Update();

	}

	public void Update() {
		carModel.update();
	}
}
