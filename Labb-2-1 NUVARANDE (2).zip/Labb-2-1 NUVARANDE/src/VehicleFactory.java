import java.awt.*;
import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

public class VehicleFactory {
    public static Volvo240 createVolvo(){
        return new Volvo240();
    }
    public static Saab95 createSaab(){
        return new Saab95();
    }
    public static Scania createScania(){
        return new Scania();
    }

    public static Car createDesiredVehicle(String requestedVehicle) throws IllegalArgumentException{
        requestedVehicle = requestedVehicle.toUpperCase();
        if(requestedVehicle.isEmpty()) throw new IllegalArgumentException("Empty input String.");
        switch (requestedVehicle){
            case "SCANIA":
                return new Scania();
            case "SAAB95":
                return new Saab95();
            case "VOLVO240":
                return new Volvo240();
            case "RANDOM":
                int randomVehicle = ThreadLocalRandom.current().nextInt(0, 3);
                Car car;
                switch (randomVehicle){
                    case 0: // SCANIA
                        //... Call Factory?
                        car = (VehicleFactory.createDesiredVehicle("Scania"));
                        break;
                    case 1: // VOLVO
                        // ... Call Factory?
                        car = (VehicleFactory.createDesiredVehicle("Volvo240"));
                        break;
                    case 2: // SAAB
                        // ... Call Factory?
                        car = (VehicleFactory.createDesiredVehicle("Saab95"));
                        break;
                    default:
                        throw new IllegalArgumentException("What");
                }
                return car;
            default:
                throw new IllegalArgumentException("Non-defined Vehicle-type.");
        }

    }
    public static ArrayList<Car> standardVehicles(){
        ArrayList<Car> vehicles = new ArrayList<>();
        Car volvo = new Volvo240();
        Car saab = new Saab95();
        Car scania = new Scania();

        volvo.setPosition(new Point(100,100));
        saab.setPosition(new Point(100,300));
        scania.setPosition(new Point(100,500));

        //saab.turnRight();
        volvo.turnRight();
        volvo.turnRight();

        vehicles.add(volvo);
        vehicles.add(saab);
        vehicles.add(scania);

        return vehicles;
    }
}
