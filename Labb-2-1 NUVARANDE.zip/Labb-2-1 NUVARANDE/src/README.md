# DIT952-lab1
Laboration 1 till Objekt-orienterad Programmering och Design 2017 (DIT952).

Se Lab1PM.txt samt Lab1del2PM.txt för instruktioner.
