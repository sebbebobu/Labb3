import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class VehicleSpeedList extends JPanel implements UpdateObserver {

	public VehicleSpeedList(){
		this.setBackground(new Color(0,0,0,25));
		this.setLocation(0,0);
		this.setLayout(new GridLayout(10,1));
		this.setPreferredSize(new Dimension(150,300));

	}

	public void updateSpeeds(ArrayList<String> classNames, ArrayList<Double> speeds) throws IllegalArgumentException{
		this.removeAll();
		if (classNames.size() != speeds.size()) throw new IllegalArgumentException("Uneven list-lengths!");
		System.out.println("Length: "+classNames.size());
		for (int i = 0; i < classNames.size(); i++){
			String string = "<"+classNames.get(i)+"> : <"+speeds.get(i)+">";
			this.add(new JLabel(string));
		}
		this.revalidate();
	}
	@Override
	public void actOnUpdate(ArrayList<String> vehicleNames, ArrayList<Point> carPoints, ArrayList<Double> speeds) {
		updateSpeeds(vehicleNames,speeds);
	}
}
